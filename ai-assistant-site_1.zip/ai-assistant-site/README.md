# Nudge — AI Assistant Landing Page

A one-page site for an AI desktop assistant: a floating helper that reads your
notes, manages email/calendar, answers as a website chatbot, and can control
your computer directly.

## Structure

```
.
├── index.html        # all page content
├── css/
│   └── styles.css    # all styling
├── js/
│   └── script.js     # small scroll behavior for the top bar
└── README.md
```

## Running locally

No build step — just open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Hosting on GitHub Pages

1. Push this folder to a GitHub repository.
2. In the repo, go to **Settings → Pages**.
3. Under "Build and deployment", set **Source** to `Deploy from a branch`,
   pick the `main` branch and `/ (root)` folder, then save.
4. GitHub will publish the site at
   `https://<your-username>.github.io/<repo-name>/` within a minute or two.

## Customizing

- Update the "View on GitHub" and "Get the source" links in `index.html`
  to point at your actual repository.
- Swap the copy in the capability cards and hero for your assistant's real
  feature set.
- Colors and type live at the top of `css/styles.css` as CSS variables.
