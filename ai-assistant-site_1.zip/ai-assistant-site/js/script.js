// Highlight the top bar once the page has scrolled past the hero.
const topbar = document.querySelector('.topbar');

const onScroll = () => {
  if (window.scrollY > 40) {
    topbar.style.background = 'rgba(17, 19, 26, 0.9)';
    topbar.style.backdropFilter = 'blur(6px)';
  } else {
    topbar.style.background = 'transparent';
    topbar.style.backdropFilter = 'none';
  }
};

window.addEventListener('scroll', onScroll, { passive: true });
onScroll();
